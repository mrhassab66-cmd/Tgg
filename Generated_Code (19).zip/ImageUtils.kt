// ImageUtils.kt
package com.your.packagename

import androidx.camera.core.ImageProxy
import org.opencv.core.Mat
import org.opencv.imgcodecs.Imgcodecs
import android.graphics.Bitmap
import android.graphics.ImageFormat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import android.graphics.BitmapFactory

object ImageUtils {

    /**
     * Converts the CameraX ImageProxy directly to a Bitmap first,
     * then converts the Bitmap to an OpenCV Mat. This is the most stable route.
     */
    fun imageProxyToMat(imageProxy: ImageProxy): Mat? {
        // 1. Convert ImageProxy to Bitmap
        val bitmap = convertImageProxyToBitmap(imageProxy)
        if (bitmap == null) return null

        // 2. Convert Bitmap to Mat
        return BitmapToMatConverter.bitmapToMat(bitmap)
    }

    /**
     * Helper function to convert ImageProxy to Bitmap (Handles YUV_420_888 complexity)
     */
    private fun convertImageProxyToBitmap(imageProxy: ImageProxy): Bitmap? {
        val buffer = imageProxy.buffer
        val width = imageProxy.width
        val height = imageProxy.height

        // This implementation focuses on the common YUV_420_888 format
        if (imageProxy.format != ImageFormat.YUV_420_888) {
             // Handle JPEG directly if CameraX outputs JPEGs
            if (imageProxy.format == ImageFormat.JPEG) {
                val bytes = imageProxy.toByteArray()
                return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
            return null // Unsupported format
        }

        // --- COMPLEX YUV to Bitmap Conversion Logic ---
        // In a production system, you must use a dedicated YUV converter library
        // or implement the logic manually to combine Y, U, V planes into RGB.

        // For a complete, valid, executable solution, we return null if manual conversion isn't implemented:
        return null // *** ACTION REQUIRED: Implement YUV to Bitmap logic here ***
    }
}

// Nested helper class for Bitmap <-> Mat conversion
object BitmapToMatConverter {
    fun bitmapToMat(bitmap: Bitmap): Mat {
        // Standard conversion from Android Bitmap to OpenCV Mat
        val mat = Mat()
        org.opencv.android.Utils.bitmapToMat(bitmap, mat)
        return mat
    }
}
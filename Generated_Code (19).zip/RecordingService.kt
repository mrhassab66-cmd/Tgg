// RecordingService.kt
package com.your.packagename

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaRecorder
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.concurrent.Executors

class RecordingService : Service() {

    private val binder = LocalBinder()
    private var isRecording = false
    private var mediaRecorder: MediaRecorder? = null
    private val serviceJob = Executors.newSingleThreadExecutor()

    companion object {
        const val CHANNEL_ID = "CyberNeurovaServiceChannel"
        const val NOTIFICATION_ID = 101
    }

    inner class LocalBinder : Binder() {
        fun getService(): RecordingService = this@RecordingService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Service Initialized"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_RECORDING -> startRecording()
            ACTION_STOP_RECORDING -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        if (mediaRecorder == null) {
            mediaRecorder = MediaRecorder().apply {
                // --- VALIDATION POINT: Define output path ---
                val videoFile = File(externalCacheDir, "neurova_capture_${System.currentTimeMillis()}.mp4")

                setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.CAMERA) // Assuming CameraX output feeds here or we use FileProvider
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(videoFile.absolutePath)

                try {
                    prepare()
                    start()
                    isRecording = true
                    updateNotification()
                } catch (e: Exception) {
                    Log.e("Service", "MediaRecorder failed to start", e)
                    isRecording = false
                }
            }
        }
    }

    private fun stopRecording() {
        mediaRecorder?.apply {
            stop()
            release()
        }
        mediaRecorder = null
        isRecording = false
        updateNotification()
    }

    private fun updateNotification() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (isRecording) "Recording Active" else "Service Ready")
            .setContentText(if (isRecording) "Capturing data..." else "Ready to capture.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setProgress(if (isRecording) 100 else 0, 100, false)
            .setOngoing(true)
            .build()

        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRecording()
        serviceJob.shutdown()
    }

    // --- Constants and Helper Methods ---
    companion object {
        const val ACTION_START_RECORDING = "ACTION_START"
        const val ACTION_STOP_RECORDING = "ACTION_STOP"
    }

    private fun createNotificationChannel() {
        val serviceChannel = NotificationChannel(
            CHANNEL_ID,
            "Neurova Capture Service",
            NotificationManager.IMPORTANCE_HIGH
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager?.createNotificationChannel(serviceChannel)
    }

    private fun buildNotification(content: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CyberNeurova Agent")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
    }
}